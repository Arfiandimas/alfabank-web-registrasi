 <!-- ======= Services Section ======= -->
 <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Services</h2>
          <h3>We do offer awesome <span>Course Program</span> in 1 Month</h3>
          <p>there many industries need this competency</p>
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4 class="title"><a href="">Web Design & Programming</a></h4>
              <p class="description">Learn how to build functional and intuitive web</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title"><a href="">Accountant Computer</a></h4>
              <p class="description">Learn how to be great accountant</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4 class="title"><a href="">Architect Computer</a></h4>
              <p class="description">Learn how to be great architect</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-world"></i></div>
              <h4 class="title"><a href="">Graphic Design</a></h4>
              <p class="description">Learn How to be intuitive graphic designer</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
