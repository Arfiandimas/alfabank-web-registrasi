
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
            <div class="col-4">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                
                <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">Harga harus diisi dongs</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <h3>Tambah</h3>
                <form action="/admin-program-kursus/create" method="POST">
                    <?php echo csrf_field(); ?>   
                    <div class="form-group">
                        <input type="text" name="nama" placeholder="nama program kursus" id="" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="study-period">Masa studi</label>
                        <select class="form-control" id="study-period" name="masa_studi">
                            <option value="1">1 bulan</option>
                            <option value="2">2 bulan</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="number" name="harga" placeholder="harga" id="" class="form-control">
                    </div>

                    <div class="form-group">
                        <input type="number" name="kuota" placeholder="kuota siswa" id="" class="form-control">
                    </div>

                    <input type="submit" value="tambah" class="btn btn-block btn-danger">
                </form>
            </div>
            <div class="col">
                <h3>Daftar program kursus</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Waktu studi</th>
                            <th>Harga</th>
                            <th>Kuota</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $program_kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($index = $index + 1); ?></th>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->masa_studi); ?> bulan</td>
                            <td><?php echo e($item->harga); ?> .000.000</td>
                            <td><?php echo e($item->kuota); ?> siswa</td>
                            <td>
                                <a href="admin-program-kursus-update.html" class="btn btn-sm btn-info">ubah</a>
                                <a href="#" class="btn btn-sm btn-danger">hapus</a>
                            </td>
                        </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/program_kursus.blade.php ENDPATH**/ ?>