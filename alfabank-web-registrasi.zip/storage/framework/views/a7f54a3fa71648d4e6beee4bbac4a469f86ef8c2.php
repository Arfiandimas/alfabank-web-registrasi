<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/vendor/larecipe/partials/sidebar.blade.php ENDPATH**/ ?>