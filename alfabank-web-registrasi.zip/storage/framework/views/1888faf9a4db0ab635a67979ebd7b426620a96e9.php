
<?php $__env->startSection('content'); ?>

<div class="mt-3">
    <form action="/admin-cari" method="get">
        <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
            <input 
                type="text" 
                class="form-control" 
                placeholder="Cari" 
                name="keyword">

            <div class="input-group-append">
                <button 
                    class="btn btn-outline-secondary" 
                    type="submit">
                    cari
                </button>
            </div>
    </form>
</div>


<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Program</th>
            <th>Masa Studi</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($user_data->firstItem() + $index); ?></th>
            <td><?php echo e($data->users->nama); ?> </td>
            <td><?php echo e($data->users->email); ?></td>
            <td><?php echo e($data->users->alamat); ?></td>
            <td><?php echo e($data->programKursus->nama); ?></td>
            <td><?php echo e($data->programKursus->masa_studi); ?></td>

            <td><?php echo e($data->status); ?></td>
            <td>
                <a href="admin-detail/<?php echo e($data->id); ?>" class="btn btn-sm btn-info">detail</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<div>
    <?php echo e($user_data->links()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>