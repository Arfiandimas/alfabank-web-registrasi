<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo $__env->yieldContent('title'); ?> | User Alfabank</title>
    <link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <meta content="" name="descriptison">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="<?php echo e(asset('/img/favicon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/css/dashboard.css')); ?>">
</head>

<body>
    <?php echo $__env->make('user.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div id="main">
        <?php echo $__env->yieldContent('contents'); ?>
        
    </div>
    
    

    <script src="<?php echo e(asset('/js/dashboard.js')); ?>"></script>
</body>

</html><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/user/layouts/master.blade.php ENDPATH**/ ?>