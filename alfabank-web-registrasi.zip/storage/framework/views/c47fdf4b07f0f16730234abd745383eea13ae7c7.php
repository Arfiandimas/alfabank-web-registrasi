<div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a class="active" href="/admin-dashboard">Dashboard</a>
        <a href="/admin-inbox">Inbox <span class="badge badge-danger">5</span></a>
        <a href="/admin-sertifikasi">Sertifikasi</a>
        <a href="/admin-program-kursus">Program Kursus</a>
        <a href="/admin-logout">Keluar</a>
</div><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>