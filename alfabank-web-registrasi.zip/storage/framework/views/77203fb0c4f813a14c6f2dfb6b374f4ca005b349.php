
<?php $__env->startSection('title','Login ad'); ?>
<?php $__env->startSection('konten'); ?>
<!-- ======= register Section ======= -->
<section id="login" class="contact">
    <div class="container">
        <div class="section-title">
            <h2>Admin Login Form</h2>
            <h3>let's fill this<span>form</span></h3>
        </div>

        <div class="row mt-5">
            <div class="col-lg-12 mt-5 mt-lg-0">
            <form action="<?php echo e(route('admin-login-action')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input 
                            type="email" 
                            class="form-control" 
                            name="email" 
                            id="email" 
                            placeholder="Email" />
                    </div>

                    <div class="form-group">
                        <input 
                            type="password" 
                            class="form-control" 
                            name="password" 
                            id="password"
                            placeholder="Password" />
                    </div>

                    <div class="text-center">
                        <button class="custom-button mt-2" type="submit">Login</button>
                    </div>
                </form>
            </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/login.blade.php ENDPATH**/ ?>