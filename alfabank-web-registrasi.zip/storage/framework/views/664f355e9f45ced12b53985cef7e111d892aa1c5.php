
<?php $__env->startSection('content'); ?>

<div class="mt-3">
    <ul class="nav nav-tabs mb-5">
        <li class="nav-item">
            <a class="nav-link" href="/admin-inbox">Inbox masuk <span class="badge badge-pill badge-danger">5</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="/admin-inbox-sudah-dibaca">Sudah dibaca</a>
        </li>
    </ul>
    <?php $__currentLoopData = $all_inbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="media p-3">
            <img class="rounded-circle" width="70" height="70" class="mr-1" src="img/ava/avatar-02-512.webp"
                alt="Generic placeholder image">
            <div class="media-body pl-2">
                <h5 class="my-0"><?php echo e($inbox->nama); ?></h5>
                <i><?php echo e($inbox->email); ?></i> | <?php echo e($inbox->created_at->diffForHumans()); ?>

                <h5 class="my-0"><span class="badge badge-pill badge-info"><?php echo e($inbox->subjek); ?></span></h5>

                <p class="mt-2"><?php echo e($inbox->pesan); ?></p>
     
                
                <form action="/admin-inbox-delete/<?php echo e($inbox->id); ?>" method="POST">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?> 
                    <input type="submit" class="btn btn-sm btn-outline-danger float-right" value="hapus pesan" />
                </form>

              
            </div>
        </div>
    </div>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/inbox_sudah_dibaca.blade.php ENDPATH**/ ?>