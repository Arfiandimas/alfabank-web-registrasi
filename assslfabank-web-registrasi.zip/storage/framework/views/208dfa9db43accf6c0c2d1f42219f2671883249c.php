  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h3>Welcome to <strong>Alfabank</strong></h3>
      <h1>Kursus singkat kerja didapat</h1>
      <h2>Build Skill, Build the World</h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->
<?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/components/hero.blade.php ENDPATH**/ ?>