
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <h3>Learn More <span>About Us</span></h3>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
              <?php echo e($artikel_kiri); ?>

            </p>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              <?php echo e($artikel_kanan); ?>

           </p>
           <p><?php echo e($berdiri_sejak); ?></p>

           cara 1
            </br>
           <?php for($i=0 ;$i<3; $i = $i+1): ?>
            <?php echo e($program_kursus[$i]); ?>

           <?php endfor; ?>

           
          </br>
            cara 2
           <?php echo e($program_kursus[0]); ?>

           <?php echo e($program_kursus[1]); ?>

           <?php echo e($program_kursus[2]); ?>

            </br> 
           cara 3 
            <?php $__currentLoopData = $program_kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge badge-primary badge-pill"><?php echo e($element); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </br>


            

            cara 4 : menampilkan data dari tabel program kursus dalam database
            <?php $__currentLoopData = $data_program_kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge badge-danger badge-pill"><?php echo e($program->nama); ?> </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="btn-learn-more">Learn More</a>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
<?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/components/about.blade.php ENDPATH**/ ?>