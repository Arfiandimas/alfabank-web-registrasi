
<?php $__env->startSection('content'); ?>
<div class="mt-3 card p-3">


    <div class="row">
        <div class="col-4">
            <img width="300" height="300" src="assets/img/team/team-1.jpg" class="rounded" alt="">
        </div>

        <div class="col-8">
        <h1><?php echo e($data->users->nama); ?></h1>
            <p><?php echo e($data->users->email); ?></p>
            <h5 class="my-0">
                <span class="badge badge-pill badge-info">
                    <?php echo e($data->programKursus->nama); ?>

                </span>
            </h5>
            <hr>

            <p><?php echo e($data->users->tanggal_lahir); ?></p>
            <p>jalan kregan utama no 33</p>
            <p>laki-laki</p>
            <p>Islam</p>
            <hr>

            <div class="form-group">
                <label for="religion">Status</label>
                <select class="form-control" id="religion" name="religion">
                    <option value="belum_verifikasi">Belum diverifikasi</option>
                    <option value="masa_studi">Masa studi</option>
                </select>
            </div>

            <a href="#" class="btn btn-block btn-outline-info">Update status</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/admin/detail.blade.php ENDPATH**/ ?>