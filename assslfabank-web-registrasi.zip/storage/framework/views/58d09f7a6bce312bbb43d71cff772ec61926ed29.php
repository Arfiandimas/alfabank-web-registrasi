 <!-- ======= Cta Section ======= -->
 <section id="cta" class="cta">
      <div class="container">

        <div class="text-center">
          <h3>Register Our Course Program</h3>
          <p>Register our course program and choose best course program for you</p>
          <a class="cta-btn" href="user-register.html">Register</a>
        </div>

      </div>
    </section><!-- End Cta Section --><?php /**PATH D:\alfabank\alfabank-web-registrasi\resources\views/components/register.blade.php ENDPATH**/ ?>