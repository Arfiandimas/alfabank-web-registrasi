<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="">Dashboard</a>
    <a href="">Sertifikat</a>
    <a href="/pengaturan">Pengaturan</a>
    <a href="/logout">Keluar</a>
</div>