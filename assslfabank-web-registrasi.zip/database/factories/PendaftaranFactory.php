<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pendaftaran;
use Faker\Generator as Faker;

$factory->define(Pendaftaran::class, function (Faker $faker) {
    return [
        //
    ];
});
