<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sertifikat;
use Faker\Generator as Faker;

$factory->define(Sertifikat::class, function (Faker $faker) {
    return [
        //
    ];
});
